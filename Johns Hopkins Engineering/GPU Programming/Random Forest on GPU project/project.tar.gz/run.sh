#!/bin/sh
echo "Starting Make..."
make
./project.exe




